<?php
    require_once 'include/header.php';   
?>
<div class="container">
    <div class="col-6 m-auto ">
        <div class="card mb-4 mt-3">
            <div class="card-header bg-info text-center">Add ad</div>
            <div class="card-body">
                <form action="allads_post_db.php" method="POST" enctype="multipart/form-data">

                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" name="title">
                    </div>


                    <!-- <div class="form-group form-group-inline">		
									<label for="">Image File :</label>
									<input type="file" name="image" id="image" class="form-control">
								</div> -->
                    
								<div class="col-md-3" style="padding-top: 12px;">
								<img id="showImage" src="image/<?php echo $im_m['image'];?>" style="height:300px; width:400px; border: 1px solid black">
								</div>

                                <div class="form-group form-group-inline">		
									<label for="">Image File :</label>
									<input type="file" name="image" id="image" class="form-control">
								</div>
                    <div class="form-group">
                        <label>Discription</label>
                        <textarea  type="text" class="form-control" name="discription"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Price</label>
                        <input type="number" class="form-control" name="price">
                    </div>
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" class="form-control" name="location">
                    </div>
                    <div class="form-group">
                        <label>Catagory</label>
                        <input type="text" class="form-control" name="catagory">
                    </div>
                    <div class="form-group">
                        <label>Contact</label>
                        <input type="tel" class="form-control" name="contact">
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Add ad</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
    require_once 'include/footer.php';
?>
<script type="text/javascript">
			 $(document).ready(function(){
$('#image').change(function(e){
var reader = new FileReader();
reader.onload = function(e){
	$('#showImage').attr('src',e.target.result);
}
reader.readAsDataURL(e.target.files['0']);
});
			 });
			 
			 </script>