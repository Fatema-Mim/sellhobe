<?php
    require_once 'include/header.php';
    session_start();   
?>
<div class="container">
    <div class="col-6 m-auto ">
        <div class="card mb-4 mt-3">
            <div class="card-header bg-info text-center">Registration</div>
            <div class="card-body">
                <form action="registration_post_db.php" method="POST">

                    <div class="mb-3 row">
                        <label for="staticEmail" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="name" value="" name="name">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="staticEmail" class="col-sm-2 col-form-label">Phone</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" id="phone" value="" name="phone">
                        </div>
                    </div>
                    <?php
                        if(isset($_SESSION["alert"])){
                            echo $_SESSION["alert"];
                        }
                    ?>
                    <div class="mb-3 row">
                        <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="Password" name="password">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="inputPassword" class="col-sm-2 col-form-label">Confirm Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                    </div>
                    
                    <br>
                    <button type="submit" class="btn btn-primary" name="sign_up">Sign Up</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
    require_once 'include/footer.php';   
?>