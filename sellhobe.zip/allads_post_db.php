<?php

$title = $_POST['title'];
$img = $_FILES["image"];
	$file_name = $img['tmp_name'];
	$destination = $img['name'];
	if(move_uploaded_file($file_name, "image/".$destination)){
$discription = $_POST['discription'];
$price = $_POST['price'];
$location = $_POST['location'];
$catagory = $_POST['catagory'];
$contact = $_POST['contact'];

require_once 'include/db.php';  
$insert= "INSERT INTO allads(title,image,description,price,location,catagory,contact,reg_date) VALUES ('$title','$destination','$discription','$price','$location','$catagory','$contact',NOW())";
$query = mysqli_query($connection, $insert);

header('location: ads_list.php');
    }
?>